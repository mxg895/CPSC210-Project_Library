package exceptions;

public class DuplicateBookException extends Throwable {
}
