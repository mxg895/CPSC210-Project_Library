package exceptions;

public class UnavailableBookException extends Throwable {
}
