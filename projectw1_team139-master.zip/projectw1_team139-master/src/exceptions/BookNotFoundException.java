package exceptions;

public class BookNotFoundException extends Throwable {
}
